package com.imcode.db.exceptions;

import com.imcode.db.DatabaseException;

import java.sql.SQLException;

public class StringTruncationException extends DatabaseException {

    public StringTruncationException( String message, SQLException ex ) {
        super( message, ex);
    }
}
