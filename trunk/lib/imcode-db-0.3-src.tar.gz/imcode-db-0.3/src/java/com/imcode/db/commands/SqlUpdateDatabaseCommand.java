package com.imcode.db.commands;

import com.imcode.db.DatabaseConnection;
import com.imcode.db.DatabaseException;
import com.imcode.db.DatabaseCommand;

/** @deprecated Use {@link SqlUpdateCommand} */
public class SqlUpdateDatabaseCommand extends SqlUpdateCommand {

    public SqlUpdateDatabaseCommand(String sql, Object[] parameters) {
        super(sql, parameters);
    }
}
