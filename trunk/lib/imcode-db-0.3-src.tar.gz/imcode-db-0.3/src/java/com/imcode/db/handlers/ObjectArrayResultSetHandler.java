package com.imcode.db.handlers;

/** @deprecated Use {@link ObjectArrayHandler} */
public class ObjectArrayResultSetHandler extends ObjectArrayHandler {

    public ObjectArrayResultSetHandler(RowTransformer rowTransformer) {
        super(rowTransformer) ;
    }

    public ObjectArrayResultSetHandler(ObjectFromRowFactory rowTransformer) {
        super(rowTransformer);
    }
}
