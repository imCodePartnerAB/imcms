package com.imcode.db.exceptions;

import com.imcode.db.DatabaseException;

import java.sql.SQLException;

public class IntegrityConstraintViolationException extends DatabaseException {

    public IntegrityConstraintViolationException( String message, SQLException ex ) {
        super(message, ex) ;
    }
}
