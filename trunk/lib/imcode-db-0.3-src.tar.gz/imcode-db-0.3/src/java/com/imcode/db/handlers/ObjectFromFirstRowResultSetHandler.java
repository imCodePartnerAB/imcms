package com.imcode.db.handlers;

/** @deprecated Use {@link SingleObjectHandler} */
public class ObjectFromFirstRowResultSetHandler extends SingleObjectHandler {

    public ObjectFromFirstRowResultSetHandler(RowTransformer rowTransformer) {
        super(rowTransformer);
    }

    public ObjectFromFirstRowResultSetHandler(ObjectFromRowFactory rowTransformer) {
        super(rowTransformer);
    }

}
