package com.imcode.db;

import javax.sql.DataSource;

/** @deprecated Misspelled, use {@link DataSourceDatabase} instead. */
public class DatasourceDatabase extends DataSourceDatabase {

    public DatasourceDatabase(DataSource dataSource) {
        super(dataSource);
    }
}
