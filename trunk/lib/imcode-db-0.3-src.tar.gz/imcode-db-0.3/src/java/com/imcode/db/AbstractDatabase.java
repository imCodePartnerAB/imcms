package com.imcode.db;

public abstract class AbstractDatabase implements Database {

    public Object executeCommand(DatabaseCommand databaseCommand) throws DatabaseException {
        return execute(databaseCommand) ;
    }

    public Object execute(DatabaseCommand databaseCommand) throws DatabaseException {
        return executeCommand(databaseCommand) ;
    }
}
