package com.imcode.db.handlers;

/** @deprecated Use {@link RowTransformer} */
public interface ObjectFromRowFactory extends RowTransformer {


    
}
