package com.imcode.db;

public class SingleConnectionDatabase extends AbstractDatabase {

    private final DatabaseConnection connection;

    public SingleConnectionDatabase(DatabaseConnection connection) {
        this.connection = connection;
    }

    public Object execute(DatabaseCommand databaseCommand) throws DatabaseException {
        return databaseCommand.executeOn(connection) ;
    }
}
