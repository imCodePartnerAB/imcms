package com.imcode.util;

import java.util.Comparator;

public class ComparatorWrapper<E> extends ChainableReversibleNullComparator<E> {

    Comparator<E> wrappedComparator;

    public ComparatorWrapper(Comparator comparator) {
        wrappedComparator = comparator;
    }

    public int compare( E o1, E o2 ) {
        return wrappedComparator.compare( o1,o2 ) ;
    }
}