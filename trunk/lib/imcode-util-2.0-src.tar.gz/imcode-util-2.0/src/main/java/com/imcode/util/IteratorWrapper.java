package com.imcode.util;

import java.util.Iterator;

public class IteratorWrapper<E> implements Iterator<E> {

    private Iterator<E> iterator ;

    public IteratorWrapper(Iterator<E> iterator) {
        this.iterator = iterator;
    }

    public boolean hasNext() {
        return iterator.hasNext() ;
    }

    public E next() {
        return iterator.next() ;
    }

    public void remove() {
        iterator.remove();
    }
}
