package com.imcode.util;

import java.util.Iterator;

public class CountingIterator<E> extends IteratorWrapper<E> {

    int count ;
    
    public CountingIterator(Iterator<E> iterator) {
        super(iterator);
    }

    public E next() {
        E next = super.next();
        count++;
        return next ;
    }

    public int getCount() {
        return count;
    }
}
