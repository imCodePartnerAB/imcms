package com.imcode.util;

import junit.framework.TestCase;

import java.util.ArrayList;
import java.util.List;
import java.util.ListIterator;

public class ListPartitionsTest extends TestCase {

    public void testListIterator() {
        ArrayList list = new ArrayList();
        ListPartitions partitions = new ListPartitions(list, 1);
        list.add(new Object()) ;
        list.add(new Object()) ;
        list.add(new Object()) ;

        ListIterator partitionIterator = partitions.listIterator();
        assertFalse(partitionIterator.hasPrevious()) ;
        assertTrue(partitionIterator.hasNext()) ;

        partitionIterator.next();
        assertTrue(partitionIterator.hasPrevious()) ;
        assertTrue(partitionIterator.hasNext()) ;

        partitionIterator.next();
        assertTrue(partitionIterator.hasPrevious()) ;
        assertTrue(partitionIterator.hasNext()) ;

        partitionIterator.next();
        assertTrue(partitionIterator.hasPrevious()) ;
        assertFalse(partitionIterator.hasNext()) ;

        ListIterator listIterator = partitions.listIterator(3);
        assertFalse(listIterator.hasNext()) ;
    }

    public void testSize() {
        List list = new ArrayList() ;
        ListPartitions partitions = new ListPartitions(list, 2);

        assertEquals(1, partitions.size()) ;
        list.add(new Object()) ;
        assertEquals(1, partitions.size()) ;

        list.add(new Object()) ;
        assertEquals(1, partitions.size()) ;

        list.add(new Object()) ;
        assertEquals(2, partitions.size()) ;

        list.add(new Object()) ;
        assertEquals(2, partitions.size()) ;

        list.add(new Object()) ;
        assertEquals(3, partitions.size()) ;
    }

}
