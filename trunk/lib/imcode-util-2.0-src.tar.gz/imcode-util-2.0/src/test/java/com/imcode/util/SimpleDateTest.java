package com.imcode.util;

import junit.framework.*;

import java.util.Date;

public class SimpleDateTest extends TestCase {

    public void testRoundTrip() {
        Date now = new Date() ;
        assertEquals(new SimpleDate(now), new SimpleDate(new SimpleDate(now).toDate()));
    }

}