package com.imcode.util;

import junit.framework.*;
import com.imcode.util.CountingIterator;

import java.util.List;
import java.util.ArrayList;

public class CountingIteratorTest extends TestCase {

    public void testCount() {
        List list = new ArrayList() ;
        Object o = new Object();
        list.add(o) ;
        CountingIterator i = new CountingIterator(list.iterator());
        assertEquals(0, i.getCount()) ;
        assertTrue(i.hasNext()) ;
        assertEquals(0, i.getCount()) ;
        assertSame(o, i.next()) ;
        assertEquals(1, i.getCount()) ;
    }

}