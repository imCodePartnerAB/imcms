package com.imcode.util;

import java.util.Iterator;

public class IteratorWrapper implements Iterator {

    private Iterator iterator ;

    public IteratorWrapper(Iterator iterator) {
        this.iterator = iterator;
    }

    public boolean hasNext() {
        return iterator.hasNext() ;
    }

    public Object next() {
        return iterator.next() ;
    }

    public void remove() {
        iterator.remove();
    }
}
