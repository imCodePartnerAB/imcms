package com.imcode.util;

import java.util.Iterator;

public class CountingIterator extends IteratorWrapper {

    int count ;
    
    public CountingIterator(Iterator iterator) {
        super(iterator);
    }

    public Object next() {
        Object next = super.next();
        count++;
        return next ;
    }

    public int getCount() {
        return count;
    }
}
