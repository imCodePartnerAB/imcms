package com.imcode.db.commands;

import org.apache.commons.dbutils.ResultSetHandler;

public class SqlQueryDatabaseCommand extends SqlQueryCommand {

    public SqlQueryDatabaseCommand(String sql, Object[] parameters, ResultSetHandler resultSetHandler) {
        super(sql, parameters, resultSetHandler);
    }
}
