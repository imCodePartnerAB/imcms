package com.imcode.db;

public interface Database {

    Object execute( DatabaseCommand databaseCommand ) throws DatabaseException;

    /** @deprecated Use {@link #execute(DatabaseCommand)} instead. */
    Object executeCommand( DatabaseCommand databaseCommand ) throws DatabaseException;
    
}