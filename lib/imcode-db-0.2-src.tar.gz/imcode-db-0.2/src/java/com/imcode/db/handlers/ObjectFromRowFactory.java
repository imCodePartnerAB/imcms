package com.imcode.db.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;

/** @deprecated Use {@link RowTransformer} */
public interface ObjectFromRowFactory extends RowTransformer {

}
