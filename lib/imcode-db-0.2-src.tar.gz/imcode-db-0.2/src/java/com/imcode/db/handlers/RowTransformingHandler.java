package com.imcode.db.handlers;

import org.apache.commons.dbutils.ResultSetHandler;

public abstract class RowTransformingHandler implements ResultSetHandler {

    protected RowTransformer rowTransformer ;

    protected RowTransformingHandler(RowTransformer rowTransformer) {
        this.rowTransformer = rowTransformer;
    }

}
