package com.imcode.db;

import org.apache.commons.dbutils.ResultSetHandler;

import java.sql.Connection;

public interface DatabaseConnection {

    int executeUpdate( String sql, Object[] parameters ) throws DatabaseException;

    Number executeUpdateAndGetGeneratedKey( String sql, Object[] parameters ) throws DatabaseException;

    Object executeQuery( String sqlQuery, Object[] parameters,
                         ResultSetHandler resultSetHandler ) throws DatabaseException;

    Connection getConnection();
}