package com.imcode.db.handlers;

import java.lang.reflect.Array;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** @deprecated Use {@link ObjectArrayHandler} */
public class ObjectArrayResultSetHandler extends ObjectArrayHandler {

    public ObjectArrayResultSetHandler(RowTransformer rowTransformer) {
        super(rowTransformer) ;
    }
}
