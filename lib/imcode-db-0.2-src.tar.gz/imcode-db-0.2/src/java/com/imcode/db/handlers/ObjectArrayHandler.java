package com.imcode.db.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.ArrayList;
import java.lang.reflect.Array;

public class ObjectArrayHandler extends RowTransformingHandler {

    public ObjectArrayHandler(RowTransformer rowTransformer) {
        super(rowTransformer) ;
    }

    public Object handle(ResultSet resultSet) throws SQLException {
        List result = new ArrayList();
        while ( resultSet.next() ) {
            result.add(( (RowTransformingHandler) this ).rowTransformer.createObjectFromResultSetRow(resultSet));
        }
        Class resultArrayType = ( (RowTransformingHandler) this ).rowTransformer.getClassOfCreatedObjects();
        return result.toArray((Object[]) Array.newInstance(resultArrayType, result.size()));
    }
}
