package com.imcode.db.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;

/** @deprecated Use {@link SingleObjectHandler} */
public class ObjectFromFirstRowResultSetHandler extends SingleObjectHandler {

    public ObjectFromFirstRowResultSetHandler(RowTransformer rowTransformer) {
        super(rowTransformer);
    }

}
