package com.imcode.db.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;

public interface RowTransformer {

    Object createObjectFromResultSetRow(ResultSet resultSet) throws SQLException;

    Class getClassOfCreatedObjects() ;
}