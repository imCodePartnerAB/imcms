package com.imcode.db.handlers;

import java.sql.ResultSet;
import java.sql.SQLException;

public class SingleObjectHandler extends RowTransformingHandler {

    public SingleObjectHandler(RowTransformer rowTransformer) {
        super(rowTransformer);
    }

    public Object handle(ResultSet resultSet) throws SQLException {
        if (!resultSet.next()) {
            return null ;
        }
        return ( (RowTransformingHandler) this ).rowTransformer.createObjectFromResultSetRow(resultSet) ;
    }
}
