package com.imcode.db;

public interface Database {

    Object executeCommand( DatabaseCommand databaseCommand ) throws DatabaseException;
}