package com.imcode.db.commands;

import com.imcode.db.DatabaseCommand;
import com.imcode.db.DatabaseConnection;
import com.imcode.db.DatabaseException;

public class SqlUpdateDatabaseCommand implements DatabaseCommand {

    private final String sqlStr;
    private final Object[] parameters;

    public SqlUpdateDatabaseCommand( String sqlStr, Object[] parameters ) {
        this.sqlStr = sqlStr;
        this.parameters = parameters;
    }

    public Object executeOn( DatabaseConnection connection ) throws DatabaseException {
        return new Integer( connection.executeUpdate( sqlStr, parameters ) );
    }
}
