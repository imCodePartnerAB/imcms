package com.imcode.db;

public interface DatabaseCommand {

    Object executeOn( DatabaseConnection connection ) throws DatabaseException ;

}
